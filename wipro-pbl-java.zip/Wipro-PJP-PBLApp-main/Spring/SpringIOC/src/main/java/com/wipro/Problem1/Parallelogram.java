package com.wipro.Problem1;

public class Parallelogram extends Shape {

	public void draw() {
		System.out.println("in Parallelogram class draw() method");
	}
}
