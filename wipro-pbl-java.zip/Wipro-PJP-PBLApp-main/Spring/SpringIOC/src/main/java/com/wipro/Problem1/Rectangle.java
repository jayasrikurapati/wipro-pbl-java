package com.wipro.Problem1;

public class Rectangle extends Shape {
	
	public void draw() {
		System.out.println("in Rectangle class draw() method");
	}
}
