package com.wipro.Problem1;

public abstract class Shape {

	public abstract void draw();
	
}
