package com.subho.wipro.pjp.tm02.stringbuffer;

public class Q7 {
	public static void main(String[] args) {
		String str = "xHix";
		
		str = str.replace("x", "");
		System.out.println(str);
	}
}
