package Employee;

public class Person {

	String person_name;
	
	public String getPersonName() {
		return this.person_name;
	}
	
	public void setPersonName(String pername) {
		this.person_name = pername;
	}
}
