package com.wipro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tm14Proj2Application {

	public static void main(String[] args) {
		SpringApplication.run(Tm14Proj2Application.class, args);
	}

}
