///WAP to calculate year of experience in Wipro. 
//number of year, number of months and days.

package dateTImeAPI;

public class Problem3 {

	public static void main(String[] args) {
		
		
	}

}
