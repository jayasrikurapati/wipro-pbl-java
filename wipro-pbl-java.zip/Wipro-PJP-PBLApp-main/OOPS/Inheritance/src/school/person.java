package school;

class person {
	
	String name;
	String dateOfBirth;
	
	public String getPersonName() {
		return this.name;
	}
	public void setPersonName(String name) {
		this.name = name;
	}
	
	public String getdateOfBirth() {
		return this.dateOfBirth;
	}
	public void setDateOfBirth(String birth) {
		this.dateOfBirth = birth;
	}
	
}
