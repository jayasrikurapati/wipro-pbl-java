create table Data_Table_2 (
    username VARCHAR2(20) NOT NULL,
    ID NUMBER(3),
    password VARCHAR2(20) NOT NULL,
    email VARCHAR2(25),
    
    PRIMARY KEY(username)
);

desc data_table_2;
