package com.subho.wipro.pjp.tm02.ea;

public class Author {
	static String name, email;
	static char gender;
	
	Author(String name, String email, char gender){
		this.name = name;
		this.email = email;
		this.gender = gender;
	}

}
