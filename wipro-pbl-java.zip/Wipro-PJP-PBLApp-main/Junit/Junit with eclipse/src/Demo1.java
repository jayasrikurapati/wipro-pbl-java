/*Method: String stringConcat(String,String)  [ returns concatenation of the 2 Strings received ]
Create the above class and method and test it using JUnit.
*/


package practice;

public class Demo1 {
	
	public String stringConcat(String s1,String s2) {
		return s1+s2;
	}
	
	public int add(int i1,int i2) {
		return i1+i2;
	}
}
