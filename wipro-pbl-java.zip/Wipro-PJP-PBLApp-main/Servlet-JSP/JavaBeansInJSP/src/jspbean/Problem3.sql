create table JSPemployee (
    name VARCHAR2(20) NOT NULL,
    ID NUMBER(3) NOT NULL,
    designation VARCHAR2(20),
    
    PRIMARY KEY(ID) 
);

desc JSPemployee;
create table JSPemployee (
    name VARCHAR2(20) NOT NULL,
    ID NUMBER(3) NOT NULL,
    designation VARCHAR2(20),
    
    PRIMARY KEY(ID) 
);

desc JSPemployee;

select * from JSPemployee;