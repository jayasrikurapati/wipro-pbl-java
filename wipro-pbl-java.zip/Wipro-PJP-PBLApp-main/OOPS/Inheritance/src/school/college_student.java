package school;

class college_student extends student{
	
	String collegeName;
	String studyingYear;
	
	public String getCollegeName() {
		return this.collegeName;
	}
	public void setCollegeName(String name) {
		this.collegeName = name;
	}
	
	public String getStudyingYear() {
		return this.studyingYear;
	}
	public void setStudyingYear(String Year) {
		this.studyingYear = Year;
	}
	
}
