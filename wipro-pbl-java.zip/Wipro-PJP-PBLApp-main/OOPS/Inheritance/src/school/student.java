package school;

class student extends person{
	
	int studentID;
	
	public int getStudentID() {
		return this.studentID;
	}
	public void setStudentID(int id) {
		this.studentID = id;
	}
	
}
