
public class Language_Basics_2 {

	public static void main(String[] args){
		// TODO Auto-generated method stub
		if(args.length!=0){
			System.out.println("Hello "+args[0]);
		}
	}
}
