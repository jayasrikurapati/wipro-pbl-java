/**
 * Write a js code to display the current system date and time.
 * Save the code as Sample.js, invoke it using jjs tool and display the result.
 */

var d1 = Java.type("java.util.Date");
var date = new d1();
print(date);